import matplotlib.pyplot as plt
squares = [1,4,9,16,25,36]
plt.plot(squares, linewidth=5)

plt.show()
