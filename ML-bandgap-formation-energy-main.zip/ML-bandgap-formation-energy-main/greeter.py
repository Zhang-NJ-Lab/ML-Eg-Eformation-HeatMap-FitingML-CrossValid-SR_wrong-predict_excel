name = input("Please enter your name: ")
print("Hello, " + name + "!")
promote = "If you tell us who you are ,we can personalize the message you see."
promote += "\nWhat is your first name？"
name = input(promote)
print("\nHello, " + name + "!")
age = input("How old are you? ")