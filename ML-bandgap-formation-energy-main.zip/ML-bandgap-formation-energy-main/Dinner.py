Dinner = input("How many people will eat here? ")
Dinner = int(Dinner)
if Dinner >= 8:
    print("\nSorry,we don't have free seat! ")
else:
    print("Yes,please! ")

