message = input("What's your name? ")
print(message)
